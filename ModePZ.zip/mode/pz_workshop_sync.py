"""Copy Project Zomboid Workshop content from the client to the server."""

from __future__ import annotations

import argparse
import logging
import os
import shutil
import sys
import tomllib
from dataclasses import dataclass, field
from pathlib import Path


CONFIG_TEMPLATE = """\
# Enter the Workshop content folders that contain mod folders such as 108600.
# Use TOML strings; single quotes are convenient for Windows paths.
client_workshop_content = ""
server_workshop_content = ""
"""

APPWORKSHOP_FILENAME = "appworkshop_108600.acf"
LOGGER = logging.getLogger("pz_workshop_sync")


@dataclass
class SyncStats:
    """Keep a summary of successful and planned synchronization work."""

    found: int = 0
    copied: int = 0
    skipped: int = 0
    transferred_bytes: int = 0
    failures: list[str] = field(default_factory=list)


def configure_logging(script_dir: Path) -> None:
    """Send log messages to both the console and the script's log file."""
    LOGGER.setLevel(logging.INFO)
    LOGGER.handlers.clear()
    formatter = logging.Formatter("%(asctime)s %(levelname)s: %(message)s")

    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    file_handler = logging.FileHandler(
        script_dir / "pz_sync.log", encoding="utf-8"
    )
    file_handler.setFormatter(formatter)
    LOGGER.addHandler(console_handler)
    LOGGER.addHandler(file_handler)


def parse_arguments() -> argparse.Namespace:
    """Parse command-line options."""
    parser = argparse.ArgumentParser(
        description="Copy downloaded Project Zomboid Workshop mods to a server."
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="show planned copies without changing Workshop files",
    )
    copy_mode = parser.add_mutually_exclusive_group()
    copy_mode.add_argument(
        "--overwrite",
        action="store_true",
        help="merge changed existing mods into the server (never delete files)",
    )
    copy_mode.add_argument(
        "--only-new",
        action="store_true",
        help="copy missing mods only (the default)",
    )
    parser.add_argument(
        "--config",
        type=Path,
        help="config.toml path (default: next to this script)",
    )
    parser.add_argument(
        "--client-workshop",
        type=Path,
        help="override client_workshop_content from the config",
    )
    parser.add_argument(
        "--server-workshop",
        type=Path,
        help="override server_workshop_content from the config",
    )
    return parser.parse_args()


def create_config_template(config_path: Path) -> bool:
    """Create a blank config template; return False if it could not be written."""
    try:
        config_path.write_text(CONFIG_TEMPLATE, encoding="utf-8")
    except OSError as error:
        LOGGER.error("Could not create config template at %s: %s", config_path, error)
        return False

    LOGGER.info(
        "Created %s. Fill in both Workshop content paths, then run the tool again.",
        config_path,
    )
    return True


def read_config(config_path: Path) -> dict[str, object] | None:
    """Read a TOML config file, creating a template if it does not exist."""
    if not config_path.is_file():
        if create_config_template(config_path):
            return None
        return None

    try:
        with config_path.open("rb") as config_file:
            config = tomllib.load(config_file)
    except (OSError, tomllib.TOMLDecodeError) as error:
        LOGGER.error("Could not read config %s: %s", config_path, error)
        return None

    return config


def configured_path(
    config: dict[str, object],
    key: str,
    override: Path | None,
    config_dir: Path,
) -> Path | None:
    """Resolve a configured or CLI-supplied path."""
    if override is not None:
        return override.expanduser().resolve()

    value = config.get(key)
    if not isinstance(value, str) or not value.strip():
        LOGGER.error(
            "Config key %r is missing or empty. Set it in the config or pass its CLI override.",
            key,
        )
        return None

    path = Path(value).expanduser()
    if not path.is_absolute():
        path = config_dir / path
    return path.resolve()


def validate_workshop_paths(client: Path, server: Path) -> bool:
    """Validate both content folders and disallow overlapping trees."""
    for label, path in (
        ("Client Workshop content", client),
        ("Server Workshop content", server),
    ):
        if not path.exists():
            LOGGER.error("%s path does not exist: %s", label, path)
            return False
        if not path.is_dir():
            LOGGER.error("%s path is not a directory: %s", label, path)
            return False

    if client == server or client in server.parents or server in client.parents:
        LOGGER.error(
            "Client and server Workshop paths must be separate, non-overlapping directories."
        )
        return False
    return True


def file_count_and_size(directory: Path) -> tuple[int, int]:
    """Return the number of files and their total bytes below a directory."""
    count = 0
    size = 0

    def raise_walk_error(error: OSError) -> None:
        raise error

    for root, directories, filenames in os.walk(
        directory, onerror=raise_walk_error
    ):
        directories[:] = [
            name for name in directories if not (Path(root) / name).is_symlink()
        ]
        for filename in filenames:
            file_path = Path(root) / filename
            if file_path.is_file():
                file_stat = file_path.stat()
                count += 1
                size += file_stat.st_size
    return count, size


def record_failure(stats: SyncStats, label: str, error: OSError | shutil.Error) -> None:
    """Log a filesystem failure and retain it for the final report."""
    message = f"{label}: {error}"
    LOGGER.error("%s", message)
    stats.failures.append(message)


def sync_acf(
    client_content: Path,
    server_content: Path,
    dry_run: bool,
    stats: SyncStats,
) -> None:
    """Copy a newer client appworkshop file after backing up the server file."""
    client_acf = client_content.parent.parent / APPWORKSHOP_FILENAME
    server_acf = server_content.parent.parent / APPWORKSHOP_FILENAME

    if not client_acf.is_file() or not server_acf.is_file():
        LOGGER.warning(
            "Workshop ACF sync skipped; client or server file is missing (%s, %s).",
            client_acf,
            server_acf,
        )
        return

    try:
        if server_acf.stat().st_mtime >= client_acf.stat().st_mtime:
            LOGGER.info("Server ACF is current; no ACF copy needed.")
            return
        backup_path = Path(f"{server_acf}.bak")
        acf_size = client_acf.stat().st_size
        backup_size = server_acf.stat().st_size
        if dry_run:
            LOGGER.info(
                "DRY RUN: would back up %s and copy newer client ACF to %s.",
                server_acf,
                server_acf,
            )
            stats.transferred_bytes += acf_size + backup_size
            return

        if not backup_path.exists():
            shutil.copy2(server_acf, backup_path)
            stats.transferred_bytes += backup_size
        else:
            LOGGER.warning(
                "Preserving existing ACF backup and using it before updating: %s",
                backup_path,
            )
        shutil.copy2(client_acf, server_acf)
        stats.transferred_bytes += acf_size
        LOGGER.info("Updated server ACF; backup saved as %s.", backup_path)
    except (PermissionError, FileNotFoundError, shutil.Error, OSError) as error:
        record_failure(stats, "ACF synchronization failed", error)


def synchronize_mods(
    client_content: Path,
    server_content: Path,
    dry_run: bool,
    overwrite: bool,
    stats: SyncStats,
) -> None:
    """Copy missing mods and optionally merge updates to existing mod folders."""
    try:
        mod_folders = sorted(
            (path for path in client_content.iterdir() if path.is_dir()),
            key=lambda path: path.name.casefold(),
        )
    except (PermissionError, FileNotFoundError, OSError) as error:
        record_failure(stats, f"Could not list client Workshop content {client_content}", error)
        return

    stats.found = len(mod_folders)
    LOGGER.info("Found %d mod folders in the client Workshop content.", stats.found)

    for source_mod in mod_folders:
        target_mod = server_content / source_mod.name
        try:
            source_count, source_size = file_count_and_size(source_mod)
            if not target_mod.exists():
                if dry_run:
                    LOGGER.info("DRY RUN: would copy new mod %s.", source_mod.name)
                    stats.copied += 1
                    stats.transferred_bytes += source_size
                else:
                    shutil.copytree(source_mod, target_mod)
                    stats.copied += 1
                    stats.transferred_bytes += source_size
                    LOGGER.info("Copied new mod %s.", source_mod.name)
                continue

            if not target_mod.is_dir():
                raise FileNotFoundError(
                    f"Target exists but is not a mod directory: {target_mod}"
                )

            target_count, _ = file_count_and_size(target_mod)
            changed = (
                source_count != target_count
                or source_mod.stat().st_mtime_ns != target_mod.stat().st_mtime_ns
            )
            if not changed:
                stats.skipped += 1
                LOGGER.info("Skipped unchanged mod %s.", source_mod.name)
                continue

            if not overwrite:
                stats.skipped += 1
                LOGGER.info(
                    "Skipped changed mod %s; use --overwrite to merge its files.",
                    source_mod.name,
                )
                continue

            if dry_run:
                LOGGER.info("DRY RUN: would merge updated mod %s.", source_mod.name)
                stats.copied += 1
                stats.transferred_bytes += source_size
            else:
                shutil.copytree(source_mod, target_mod, dirs_exist_ok=True)
                stats.copied += 1
                stats.transferred_bytes += source_size
                LOGGER.info("Merged updated mod %s.", source_mod.name)
        except (PermissionError, FileNotFoundError, shutil.Error, OSError) as error:
            record_failure(stats, f"Could not synchronize mod {source_mod.name}", error)


def format_bytes(size: int) -> str:
    """Format a byte count in a readable binary unit."""
    units = ("B", "KiB", "MiB", "GiB", "TiB")
    amount = float(size)
    for unit in units:
        if amount < 1024 or unit == units[-1]:
            return f"{amount:.1f} {unit}"
        amount /= 1024
    return f"{size} B"


def main() -> int:
    """Run config validation, ACF synchronization, and mod synchronization."""
    script_dir = Path(__file__).resolve().parent
    configure_logging(script_dir)
    args = parse_arguments()
    config_path = (args.config or script_dir / "config.toml").expanduser().resolve()

    config_was_present = config_path.is_file()
    config = read_config(config_path)
    if config is None:
        return 1 if config_was_present or not config_path.is_file() else 0

    client_content = configured_path(
        config, "client_workshop_content", args.client_workshop, config_path.parent
    )
    server_content = configured_path(
        config, "server_workshop_content", args.server_workshop, config_path.parent
    )
    if client_content is None or server_content is None:
        return 1
    if not validate_workshop_paths(client_content, server_content):
        return 1

    stats = SyncStats()
    sync_acf(client_content, server_content, args.dry_run, stats)
    synchronize_mods(
        client_content,
        server_content,
        args.dry_run,
        args.overwrite,
        stats,
    )

    count_label = "would be copied" if args.dry_run else "copied"
    data_label = "data to transfer" if args.dry_run else "data transferred"
    LOGGER.info(
        "Summary: found %d mods, %d %s, skipped %d; %s: %s.",
        stats.found,
        stats.copied,
        count_label,
        stats.skipped,
        data_label,
        format_bytes(stats.transferred_bytes),
    )
    if stats.failures:
        LOGGER.error("Failures (%d):", len(stats.failures))
        for failure in stats.failures:
            LOGGER.error("  - %s", failure)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
