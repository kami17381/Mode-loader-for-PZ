@echo off
setlocal
py -3 "%~dp0pz_workshop_sync.py" %*
if errorlevel 1 (
    echo Workshop sync reported an error. Review pz_sync.log before starting the server.
    pause
    exit /b 1
)
echo Workshop sync finished. Start the Project Zomboid server when ready.
pause
